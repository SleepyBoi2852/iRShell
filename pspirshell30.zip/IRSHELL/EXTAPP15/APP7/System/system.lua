System.usbDiskModeActivate()

yellow = Color.new(255, 255, 0)
red = Color.new(255, 0, 0)

System.currentDirectory("ms0:/IRSHELL/EXTAPP15/APP7")

file = io.open("LUA_TEMP.CFG", "r")
if file then
        filetorun = file:read("*a")
        file:close()
end

function findpattern(text, pattern, start)
        local _, __, match = string.find(text, pattern, start)
        return match
end

-- Find the Directory
filename = findpattern(filetorun,"([^/]+)$")
dir = findpattern(filetorun,"^(.+/)[^/]+$")

for dir in string.gfind(dir, "[^/]+") do
        System.currentDirectory(dir)
end

appsDir = System.currentDirectory() 

screen:print(0,8,"Lua Player 0.16 NetLib iR Shell Plugin",yellow)
screen:print(0,16,"LUAPLAYER.PBP loader coded by Kajo5",yellow)
screen:print(0,24,"Made with the help of the legendary ahman!",yellow)
screen:print(0,40,"The path is:" .. filetorun,red)
screen:print(0,50,"The dir should be:" .. dir,red)
screen:print(0,70,"The dir being used is:" .. System.currentDirectory(dir),red)
screen:print(0,60,"The filename is:" .. filename,red)
screen.waitVblankStart(0)
screen:flip()
screen.waitVblankStart(1)

dofile(filename)
os.exit(0)