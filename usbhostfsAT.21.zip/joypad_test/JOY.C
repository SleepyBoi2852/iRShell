#include <stdio.h>
#include <time.h>
#include <w32api/windows.h>
#include <w32api/mmsystem.h>

struct joymap{
	int unum;
	int type;
	int axis;
};
struct joymap mappedJoy[31];

JOYINFOEX joy;

int joyYCutoff = 60;
int joyXCutoff = 60;
int joyZCutoff = 60;
int joyRCutoff = 60;
int joyUCutoff = 60;
int joyVCutoff = 60;
int YAxisActive = 0;
int XAxisActive = 0;
int ZAxisActive = 0;
int RAxisActive = 0;
int UAxisActive = 0;
int VAxisActive = 0;

void delayme(float tim);
void getJoystickPress(int inp);
void SaveConfig();

main()
{
	int n;
	int rc;

	n = joyGetNumDevs();
	printf("Num of joy: %d\n", n);
	memset(&joy, 0, sizeof(joy));
	joy.dwSize = sizeof (joy);
	joy.dwFlags = JOY_RETURNALL; 
	//while (1) {
	//	rc = joyGetPos(0, &joy);
	//	printf("rc %d, buttons: %i, %X, %X, %X\n", rc, joy.dwButtons, joy.dwXpos, joy.dwYpos, joy.dwZpos);
	//}
	
		printf("Input key for DPAD UP\n");
		getJoystickPress(0);
		delayme(3);
		printf("Input key for DPAD DOWN\n");
		getJoystickPress(1);
		delayme(3);
		printf("Input key for DPAD LEFT\n");
		getJoystickPress(2);
		delayme(3);
		printf("Input key for DPAD RIGHT\n");
		getJoystickPress(3);
		delayme(3);
		
		printf("Input key for CROSS\n");
		getJoystickPress(4);
		delayme(3);
		printf("Input key for CIRCLE\n");
		getJoystickPress(5);
		delayme(3);
		printf("Input key for SQUARE\n");
		getJoystickPress(6);
		delayme(3);
		printf("Input key for TRIANGLE\n");
		getJoystickPress(7);
		delayme(3);
		printf("Input key for LTRIGGER\n");
		getJoystickPress(8);
		delayme(3);
		printf("Input key for RTRIGGER\n");
		getJoystickPress(9);
		delayme(3);
		printf("Input key for START\n");
		getJoystickPress(10);
		delayme(3);
		printf("Input key for SELECT\n");
		getJoystickPress(11);
		delayme(3);
		printf("Input key for AUP\n");
		getJoystickPress(12);
		delayme(3);
		printf("Input key for ADOWN\n");
		getJoystickPress(13);
		delayme(3);
		printf("Input key for ALEFT\n");
		getJoystickPress(14);
		delayme(3);
		printf("Input key for ARIGHT\n");
		getJoystickPress(15);
		delayme(3);
		printf("Input key for HOME\n");
		getJoystickPress(16);
		delayme(3);
		printf("Input key for EXIT\n");
		getJoystickPress(17);
		delayme(3);
		printf("Input key for 'Toggle Dpad/Analog'\n");
		getJoystickPress(18);

		delayme(3);
		printf("Input key for 'MACRO_0'\n");
		getJoystickPress(20);
		delayme(3);
		printf("Input key for 'MACRO_1'\n");
		getJoystickPress(21);
		delayme(3);
		printf("Input key for 'MACRO_2'\n");
		getJoystickPress(22);
		delayme(3);
		printf("Input key for 'MACRO_3'\n");
		getJoystickPress(23);
		delayme(3);
		printf("Input key for 'MACRO_4'\n");
		getJoystickPress(24);
		delayme(3);
		printf("Input key for 'MACRO_5'\n");
		getJoystickPress(25);
		delayme(3);
		printf("Input key for 'MACRO_6'\n");
		getJoystickPress(26);
		delayme(3);
		printf("Input key for 'MACRO_7'\n");
		getJoystickPress(27);
		delayme(3);
		printf("Input key for 'MACRO_8'\n");
		getJoystickPress(28);
		delayme(3);
		printf("Input key for 'MACRO_9'\n");
		getJoystickPress(29);
		
		delayme(1);

		printf("Saving joystickSetup.cfg\n");
		SaveConfig();

	
}

void getJoystickPress(int inp){
int exitloop;exitloop = 0;
while(exitloop == 0){
int rc;
rc = joyGetPosEx(0, &joy);
//printf("rc %d, buttons: %i, %X, %X, %X\n", rc, joy.dwButtons, joy.dwXpos, joy.dwYpos, joy.dwZpos);
if((int)joy.dwButtons != 0){
	//we've a button press
	mappedJoy[inp].type = 0;
	mappedJoy[inp].unum = (int)joy.dwButtons;
	printf("Pressed button:%i\n",mappedJoy[inp].unum);
	exitloop = 1;
}
if ((int)(joy.dwYpos/256) > 0){YAxisActive = 1;}
if ((int)(joy.dwXpos/256) > 0){XAxisActive = 1;}
if ((int)(joy.dwZpos/256) > 0){ZAxisActive = 1;}
if ((int)(joy.dwRpos/256) > 0){RAxisActive = 1;}
if ((int)(joy.dwUpos/256) > 0){UAxisActive = 1;}
if ((int)(joy.dwVpos/256) > 0){VAxisActive = 1;}
if((int)(joy.dwYpos/256) < 127-joyYCutoff && YAxisActive){
	mappedJoy[inp].type = 1;
	mappedJoy[inp].axis = 0;
	printf("Y-axis Up\n");
	exitloop = 1;
}
if((int)(joy.dwYpos/256) > 127+joyYCutoff && YAxisActive){
	mappedJoy[inp].type = 1;
	mappedJoy[inp].axis = 1;
	printf("Y-axis Down\n");
	exitloop = 1;
}
if((int)(joy.dwXpos/256) < 127-joyXCutoff && XAxisActive){
	mappedJoy[inp].type = 1;
	mappedJoy[inp].axis = 2;
	printf("X-axis Left\n");
	exitloop = 1;
}
if((int)(joy.dwXpos/256) > 127+joyXCutoff && XAxisActive){
	mappedJoy[inp].type = 1;
	mappedJoy[inp].axis = 3;
	printf("X-axis Right\n");
	exitloop = 1;
}
if((int)(joy.dwZpos/256) < 127-joyZCutoff && ZAxisActive){
	mappedJoy[inp].type = 1;
	mappedJoy[inp].axis = 4;
	printf("Z-axis Up\n");
	exitloop = 1;
}
if((int)(joy.dwZpos/256) > 127+joyZCutoff && ZAxisActive){
	mappedJoy[inp].type = 1;
	mappedJoy[inp].axis = 5;
	printf("Z-axis Down\n");
	exitloop = 1;
}

if((int)(joy.dwRpos/256) < 127-joyRCutoff && RAxisActive){
	mappedJoy[inp].type = 1;
	mappedJoy[inp].axis = 6;
	printf("R-axis Up\n");
	exitloop = 1;
}
if((int)(joy.dwRpos/256) > 127+joyRCutoff && RAxisActive){
	mappedJoy[inp].type = 1;
	mappedJoy[inp].axis = 7;
	printf("R-axis Down\n");
	exitloop = 1;
}
if((int)(joy.dwUpos/256) < 127-joyUCutoff && UAxisActive){
	mappedJoy[inp].type = 1;
	mappedJoy[inp].axis = 8;
	printf("U-axis Up\n");
	exitloop = 1;
}
if((int)(joy.dwUpos/256) > 127+joyUCutoff && UAxisActive){
	mappedJoy[inp].type = 1;
	mappedJoy[inp].axis = 9;
	printf("U-axis Down\n");
	exitloop = 1;
}
if((int)(joy.dwVpos/256) < 127-joyVCutoff && VAxisActive){
	mappedJoy[inp].type = 1;
	mappedJoy[inp].axis = 10;
	printf("V-axis Up\n");
	exitloop = 1;
}
if((int)(joy.dwVpos/256) > 127+joyVCutoff && VAxisActive){
	mappedJoy[inp].type = 1;
	mappedJoy[inp].axis = 11;
	printf("V-axis Down\n");
	exitloop = 1;
}

//add option of 'none'
if(GetAsyncKeyState(VK_ESCAPE)){
	mappedJoy[inp].type = -1;
	printf("NONE\n");
	exitloop = 1;
}

}

}

void SaveConfig(){
FILE *fp;
fp = fopen("./joystickSetup.cfg","w");
int i=0;
for(i=0;i<30;i++){
	if(i==0){fwrite("PSP_UP=",strlen("PSP_UP="),1,fp);}
	if(i==1){fwrite("PSP_DOWN=",strlen("PSP_DOWN="),1,fp);}
	if(i==2){fwrite("PSP_LEFT=",strlen("PSP_LEFT="),1,fp);}
	if(i==3){fwrite("PSP_RIGHT=",strlen("PSP_RIGHT="),1,fp);}
	if(i==4){fwrite("PSP_CROSS=",strlen("PSP_CROSS="),1,fp);}
	if(i==5){fwrite("PSP_CIRCLE=",strlen("PSP_CIRCLE="),1,fp);}
	if(i==6){fwrite("PSP_SQUARE=",strlen("PSP_SQUARE="),1,fp);}
	if(i==7){fwrite("PSP_TRIANGLE=",strlen("PSP_TRIANGLE="),1,fp);}
	if(i==8){fwrite("PSP_LTRIGGER=",strlen("PSP_LTRIGGER="),1,fp);}
	if(i==9){fwrite("PSP_RTRIGGER=",strlen("PSP_RTRIGGER="),1,fp);}
	if(i==10){fwrite("PSP_START=",strlen("PSP_START="),1,fp);}
	if(i==11){fwrite("PSP_SELECT=",strlen("PSP_SELECT="),1,fp);}
	if(i==12){fwrite("PSP_AUP=",strlen("PSP_AUP="),1,fp);}
	if(i==13){fwrite("PSP_ADOWN=",strlen("PSP_ADOWN="),1,fp);}
	if(i==14){fwrite("PSP_ALEFT=",strlen("PSP_ALEFT="),1,fp);}
	if(i==15){fwrite("PSP_ARIGHT=",strlen("PSP_ARIGHT="),1,fp);}
	if(i==16){fwrite("PSP_HOME=",strlen("PSP_HOME="),1,fp);}
	if(i==17){fwrite("PSP_ESCAPE=",strlen("PSP_ESCAPE="),1,fp);}
	if(i==18){fwrite("PSP_ATOGGLE=",strlen("PSP_ATOGGLE="),1,fp);}

	if(i==20){fwrite("MACRO_0=",strlen("MACRO_0="),1,fp);}
	if(i==21){fwrite("MACRO_1=",strlen("MACRO_1="),1,fp);}
	if(i==22){fwrite("MACRO_2=",strlen("MACRO_2="),1,fp);}
	if(i==23){fwrite("MACRO_3=",strlen("MACRO_3="),1,fp);}
	if(i==24){fwrite("MACRO_4=",strlen("MACRO_4="),1,fp);}
	if(i==25){fwrite("MACRO_5=",strlen("MACRO_5="),1,fp);}
	if(i==26){fwrite("MACRO_6=",strlen("MACRO_6="),1,fp);}
	if(i==27){fwrite("MACRO_7=",strlen("MACRO_7="),1,fp);}
	if(i==28){fwrite("MACRO_8=",strlen("MACRO_8="),1,fp);}
	if(i==29){fwrite("MACRO_9=",strlen("MACRO_9="),1,fp);}

	char* tempstr;tempstr = (char*)malloc(30);memset(tempstr,'\0',30);
	if(mappedJoy[i].type == 0){sprintf(tempstr,"%i",mappedJoy[i].unum);}
	if(mappedJoy[i].type == 1){
		if(mappedJoy[i].axis == 0){sprintf(tempstr,"JOYUP");}
		if(mappedJoy[i].axis == 1){sprintf(tempstr,"JOYDOWN");}
		if(mappedJoy[i].axis == 2){sprintf(tempstr,"JOYLEFT");}
		if(mappedJoy[i].axis == 3){sprintf(tempstr,"JOYRIGHT");}
		if(mappedJoy[i].axis == 4){sprintf(tempstr,"JOYZUP");}
		if(mappedJoy[i].axis == 5){sprintf(tempstr,"JOYZDOWN");}
		if(mappedJoy[i].axis == 6){sprintf(tempstr,"JOYRUP");}
		if(mappedJoy[i].axis == 7){sprintf(tempstr,"JOYRDOWN");}
		if(mappedJoy[i].axis == 8){sprintf(tempstr,"JOYUUP");}
		if(mappedJoy[i].axis == 9){sprintf(tempstr,"JOYUDOWN");}
		if(mappedJoy[i].axis ==10){sprintf(tempstr,"JOYVUP");}
		if(mappedJoy[i].axis ==11){sprintf(tempstr,"JOYVDOWN");}
	}
	if(mappedJoy[i].type == -1){sprintf(tempstr,"NONE");}
	fwrite(tempstr,strlen(tempstr),1,fp);
	free(tempstr);

	
	char* tempstr2;tempstr2 = (char*)malloc(10);memset(tempstr2,'\0',10);sprintf(tempstr2,"\n");
	fwrite(tempstr2,strlen(tempstr2),1,fp);
	free(tempstr2);
}

}

void delayme(float tim){
int beginseconds;
beginseconds = time(NULL);
while(time(NULL) < beginseconds+tim){
int rc;
rc = joyGetPosEx(0, &joy);
//if we've no buttons pressed and no axes moved, skip right to the next one
	if(GetAsyncKeyState(VK_ESCAPE)){
	}else{
		if((int)joy.dwButtons == 0){
			if(YAxisActive == 0 || ((int)(joy.dwYpos/256) > 127-joyYCutoff && (int)(joy.dwYpos/256) < 127+joyYCutoff)){
				if(XAxisActive == 0 || ((int)(joy.dwXpos/256) > 127-joyXCutoff && (int)(joy.dwXpos/256) < 127+joyXCutoff)){
					if(ZAxisActive == 0 || ((int)(joy.dwZpos/256) > 127-joyZCutoff && (int)(joy.dwZpos/256) < 127+joyZCutoff)){
						if(RAxisActive == 0 || ((int)(joy.dwRpos/256) > 127-joyRCutoff && (int)(joy.dwRpos/256) < 127+joyRCutoff)){
							if(UAxisActive == 0 || ((int)(joy.dwUpos/256) > 127-joyUCutoff && (int)(joy.dwUpos/256) < 127+joyUCutoff)){
								if(VAxisActive == 0 || ((int)(joy.dwVpos/256) > 127-joyVCutoff && (int)(joy.dwVpos/256) < 127+joyVCutoff)){
			break;
			}}}}}}
		}
	}

}

}
