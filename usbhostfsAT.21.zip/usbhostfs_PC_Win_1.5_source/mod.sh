#!/bin/sh
# Quick simple tool to set SUID on the executable
sudo chown root:root usbhostfs_pc
sudo chmod +s usbhostfs_pc
